<?php
/**
 * Default Lexicon Entries for TinyMCE Rich Text Editor
 *
 * @package tinymcerte
 * @subpackage lexicon
 */
$_lang['tinymcerte'] = 'TinyMCE Rich Text Editor';
$_lang['tinymcerte.float_left'] = 'Sinistra';
$_lang['tinymcerte.float_none'] = 'Nessuno';
$_lang['tinymcerte.float_right'] = 'Destra';
$_lang['tinymcerte.select_none'] = '(Nessuno)';
$_lang['tinymcerte.select_resource'] = 'Seleziona risorsa';
