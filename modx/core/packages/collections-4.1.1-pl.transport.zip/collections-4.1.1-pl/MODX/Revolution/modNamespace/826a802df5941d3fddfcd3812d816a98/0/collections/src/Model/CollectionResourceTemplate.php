<?php
namespace Collections\Model;

use xPDO\xPDO;

/**
 * Class CollectionResourceTemplate
 *
 * @property integer $collection_template
 * @property integer $resource_template
 *
 * @package Collections\Model
 */
class CollectionResourceTemplate extends \xPDO\Om\xPDOObject
{
}
