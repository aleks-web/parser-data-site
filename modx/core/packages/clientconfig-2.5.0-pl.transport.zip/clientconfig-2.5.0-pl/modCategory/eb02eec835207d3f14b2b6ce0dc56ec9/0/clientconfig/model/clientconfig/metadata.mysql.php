<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'cgSetting',
    1 => 'cgGroup',
    2 => 'cgContextValue',
  ),
);