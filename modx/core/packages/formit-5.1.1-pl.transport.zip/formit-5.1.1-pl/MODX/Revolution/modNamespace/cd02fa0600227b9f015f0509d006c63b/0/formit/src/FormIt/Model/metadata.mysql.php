<?php
$xpdo_meta_map = array (
    'xPDO\\Om\\xPDOSimpleObject' => 
    array (
        0 => 'Sterc\\FormIt\\Model\\FormItForm',
    ),
);